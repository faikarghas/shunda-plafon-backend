@extends('twill::layouts.form')

@section('contentFields')
    @formField('wysiwyg', [
        'name' => 'description',
        'label' => 'Description',
        'toolbarOptions' => [ [ 'header' => [1, 2, false] ], 'list-ordered', 'list-unordered', [ 'indent' => '-1'], [ 'indent' => '+1' ],'link','bold', 'italic', 'underline', ],
        'maxlength' => 2000,
        'editSource' => true,
        'translated' => true,
    ])

    @formField('medias', [
        'name' => 'image',
        'label' => 'Image',
        'note' => 'Also used in listings',
        'max' => 5,
        'fieldNote' => 'Minimum image width: 1500px'
    ])
@stop
